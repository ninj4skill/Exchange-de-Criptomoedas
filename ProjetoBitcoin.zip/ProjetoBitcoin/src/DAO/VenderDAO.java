
package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import model.Compra;
import model.Saldo;

public class VenderDAO {
     private Connection conn;

    public VenderDAO(Connection conn) {
        this.conn = conn;
    }
     
      public void atualizar(Compra carteira) throws SQLException {
        String sql = "UPDATE carteira SET saldo = ? WHERE senha = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setDouble(1, carteira.getSaldoreal());
            statement.setString(2, carteira.getSenha());
            statement.executeUpdate(); // Use executeUpdate para comandos de atualização
            conn.commit(); // Garantir que a transação seja confirmada
        }
    }

    public void atualizarbtc(Compra carteira) throws SQLException {
        String sql = "UPDATE carteira SET saldobtc = ? WHERE senha = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setDouble(1, carteira.getSaldobtc());
            statement.setString(2, carteira.getSenha());
            statement.executeUpdate();
            conn.commit();
        }
    }

    public void atualizareth(Compra carteira) throws SQLException {
        String sql = "UPDATE carteira SET saldoeth = ? WHERE senha = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setDouble(1, carteira.getSaldoeth());
            statement.setString(2, carteira.getSenha());
            statement.executeUpdate();
            conn.commit();
        }
    }

    public void atualizarxrp(Compra carteira) throws SQLException {
        String sql = "UPDATE carteira SET saldoxrp = ? WHERE senha = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setDouble(1, carteira.getSaldoxrp());
            statement.setString(2, carteira.getSenha());
            statement.executeUpdate();
            conn.commit();
        }
    }
}

