package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import model.Compra;
import model.Saldo;

public class SaldoDAO {
    
    private Connection conn;

    public SaldoDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ResultSet consultar(Saldo usuarios) throws SQLException{
        
        String sql = "select * from usuarios where cpf = ? AND senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, usuarios.getCpf());
        statement.setString(2, usuarios.getSenha());
        statement.execute();
        ResultSet resultado = statement.getResultSet();
        return resultado;
        
    }
    
    public ResultSet consultarsaldo(Saldo usuarios) throws SQLException{
        
        String sql = "select * from carteira where senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, usuarios.getSenha());
        statement.execute();
        ResultSet resultado = statement.getResultSet();
        return resultado;
        
    }
    public ResultSet atualizar(Compra carteira) throws SQLException{
        
        String sql = "update carteira set saldo = ? where senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setDouble(1, carteira.getSaldoreal());
        statement.setString(2, carteira.getSenha());
        statement.execute();
        return statement.getResultSet();
        
    }
     public ResultSet atualizarbtc(Compra carteira) throws SQLException{
        
        String sql = "update carteira set btc = ? where senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setDouble(1, carteira.getSaldobtc());
        statement.setString(2, carteira.getSenha());
        statement.execute();
        return statement.getResultSet();
        
    }
     public ResultSet atualizareth(Compra carteira) throws SQLException{
        
        String sql = "update carteira set eth = ? where senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setDouble(1, carteira.getSaldoeth());
        statement.setString(2, carteira.getSenha());
        statement.execute();
        return statement.getResultSet();
        
    }
     public ResultSet atualizarxrp(Compra carteira) throws SQLException{
        
        String sql = "update carteira set xrp = ? where senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setDouble(1, carteira.getSaldoxrp());
        statement.setString(2, carteira.getSenha());
        statement.execute();
        return statement.getResultSet();
        
    }
}


