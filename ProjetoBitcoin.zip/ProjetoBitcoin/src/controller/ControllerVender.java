
package controller;

import java.sql.Connection;
import DAO.Conexao;
import DAO.SaldoDAO;
import java.sql.SQLException;
import view.VenderFrame;
import java.sql.ResultSet;
import model.Compra;
import model.Saldo;
import DAO.VenderDAO;
public class ControllerVender {
    private VenderFrame view;

    public ControllerVender(VenderFrame view) {
        this.view = view;
    }
    
    public void vender(){
    Conexao conexao = new Conexao();
        System.out.println("1");
        Saldo login = new Saldo(null, "7");
        System.out.println("2");
        try{
            Connection conn = conexao.getConnection();
            SaldoDAO dao = new SaldoDAO(conn);
            ResultSet res = dao.consultarsaldo(login);
           if (res.next()){
               double real = res.getDouble("saldo");
               double btc = res.getDouble("saldobtc");
               double eth = res.getDouble("saldoeth");
               double xrp = res.getDouble("saldoxrp");
               
               double valorbtc = Double.parseDouble(view.getTxtVenderBtc().getText());
               double valoreth = Double.parseDouble(view.getTxtVenderEth().getText());
               double valorxrp = Double.parseDouble(view.getTxtVenderXrp().getText());
               double taxabtc = real * 0.02;
               double taxaeth = real * 0.01;
               double taxaxrp = real * 0.1;
               double cotacaobtc = 5000;
               double cotacaoeth = 1000;
               double cotacaoxrp = 5;
               double precobtc = valorbtc * cotacaobtc;
               double precoeth = valoreth * cotacaoeth;
               double precoxrp = valorxrp * cotacaoxrp;
               double novoReal =( (real - precobtc) - precoeth )- precoxrp;
               double novobtc = btc - valorbtc;
               double novoeth = eth - valoreth;
               double novoxrp = xrp - valorxrp;
               System.out.println(novoReal);
               System.out.println(novobtc);
               System.out.println(novoeth);
               System.out.println(novoxrp);
               
               Compra compra = new Compra("7", novoReal, novobtc, novoeth, novoxrp);
               conn = conexao.getConnection();
               VenderDAO dao2 = new VenderDAO(conn);
               dao2.atualizar(compra);
               conn = conexao.getConnection();
               VenderDAO dao3 = new VenderDAO(conn);
               dao3.atualizarbtc(compra);
               System.out.println("Faz");
               dao2.atualizareth(compra);
               System.out.println("o");
               dao2.atualizarxrp(compra);
               System.out.println("L");
               
               conn.commit();
           }else {
               System.out.println("eai");
           }
           
        } catch(SQLException e){
            System.out.println("errei fui mlk ");
        }
    }
    
}

