package controller;

import DAO.LoginDAO;
import DAO.Conexao;
import model.Login;
import view.LoginFrame;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import view.LoginFrame;
import model.Login;
import view.Menu;

public class ControllerLogin {
    private LoginFrame view;
    
    public ControllerLogin(LoginFrame view){
        this.view = view;
    }
    
    public void LoginAluno(){
        Login lf = new Login(null, view.getTxtcpf().getText(),
        view.getTxtsenha().getText());
        
        Conexao conexao = new Conexao();
        try{
            Connection conn = conexao.getConnection();
            LoginDAO dao = new LoginDAO(conn);
            ResultSet res = dao.consultar(lf);
            if (res.next()){
                JOptionPane.showMessageDialog(view, "Login feito", "Aviso",
                        JOptionPane.INFORMATION_MESSAGE);
                String nome = res.getString("nome");
                String cpf = res.getString("cpf");
                String senha = res.getString("senha");
                Login lf1 = new Login(nome, cpf, senha);
                Menu mn = new Menu();
                mn.setVisible(true);
                view.setVisible(false);
            } else{
                JOptionPane.showMessageDialog(view, "Login não foi feito", "Erro",
                        JOptionPane.ERROR_MESSAGE);
            }
            
    }catch(SQLException e){
                    JOptionPane.showMessageDialog(view, "Erro de Conexão", "Erro",
                        JOptionPane.ERROR_MESSAGE);
                    }
    
}
}
