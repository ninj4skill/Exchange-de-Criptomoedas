
package model;


public class Vender {
    private String senha;
    private double saldoreal, saldobtc, saldoeth, saldoxrp;

    public Vender() {
    }

    public Vender(String senha, double saldoreal, double saldobtc, double saldoeth, double saldoxrp) {
        this.senha = senha;
        this.saldoreal = saldoreal;
        this.saldobtc = saldobtc;
        this.saldoeth = saldoeth;
        this.saldoxrp = saldoxrp;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public double getSaldoreal() {
        return saldoreal;
    }

    public void setSaldoreal(double saldoreal) {
        this.saldoreal = saldoreal;
    }

    public double getSaldobtc() {
        return saldobtc;
    }

    public void setSaldobtc(double saldobtc) {
        this.saldobtc = saldobtc;
    }

    public double getSaldoeth() {
        return saldoeth;
    }

    public void setSaldoeth(double saldoeth) {
        this.saldoeth = saldoeth;
    }

    public double getSaldoxrp() {
        return saldoxrp;
    }

    public void setSaldoxrp(double saldoxrp) {
        this.saldoxrp = saldoxrp;
    }
    
    
}


