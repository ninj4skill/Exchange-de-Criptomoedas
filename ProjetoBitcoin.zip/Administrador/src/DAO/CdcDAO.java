
package DAO;
import java.sql.Connection;
import model.Cdc;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class CdcDAO {
    private Connection conn;

    public CdcDAO(Connection conn) {
        this.conn = conn;
    }
    public void inserir(Cdc moedas) throws SQLException{
        String sql = "insert into cripto(nome, cotacao) values('"
                + moedas.getNome() + "', '" + moedas.getCotacao() + "') ";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.execute();
        conn.close();
    }
    public void  excluir(Cdc moedas)throws SQLException{
        String sql = "delete from cripto where nome = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, moedas.getNome());
        statement.execute();
        conn.close();
    }
}
