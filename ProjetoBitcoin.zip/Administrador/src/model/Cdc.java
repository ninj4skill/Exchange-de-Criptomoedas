
package model;

public class Cdc {
    private String nome;
    private double cotacao;

    public Cdc(String nome, double cotacao) {
        this.nome = nome;
        this.cotacao = cotacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getCotacao() {
        return cotacao;
    }

    public void setCotacao(double cotacao) {
        this.cotacao = cotacao;
    }
    
    
}
