
package controller;

import DAO.CdcDAO;
import DAO.ConexaoAdm;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import view.ExcluirCripto;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Cdc;


public class ControllerEc {
    private ExcluirCripto view;

    public ControllerEc(ExcluirCripto view) {
        this.view = view;
    }
    
     public void Excluir(){
     Cdc lf = new Cdc( view.getTxtExcluir().getText(),0);
        System.out.println("1");
        
        ConexaoAdm conexao = new ConexaoAdm();
        System.out.println("2");
        try{
            Connection conn = conexao.getConnection();
            System.out.println("3");
            CdcDAO dao = new CdcDAO(conn);
            System.out.println("4");
            dao.excluir(lf);
            System.out.println("5");
            
        }catch(SQLException e){
                    JOptionPane.showMessageDialog(view, "Erro de Conexão", "Erro",
                        JOptionPane.ERROR_MESSAGE);
                    System.out.println("15");
                    }
    
}
}





