
package controller;

import DAO.ConexaoAdm;
import DAO.LoginAdmDAO;
import model.LoginAdm;
import view.Excluir;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class ControllerExcluir {
    private Excluir view;

    public ControllerExcluir(Excluir view) {
        this.view = view;
    }
    
    public void Excluir(){
     LoginAdm lf = new LoginAdm(null, view.getTxtExcluir().getText(),null);
        System.out.println("1");
        
        ConexaoAdm conexao = new ConexaoAdm();
        System.out.println("2");
        try{
            Connection conn = conexao.getConnection();
            System.out.println("3");
            LoginAdmDAO dao = new LoginAdmDAO(conn);
            System.out.println("4");
            dao.excluir(lf);
            System.out.println("5");
            
        }catch(SQLException e){
                    JOptionPane.showMessageDialog(view, "Erro de Conexão", "Erro",
                        JOptionPane.ERROR_MESSAGE);
                    System.out.println("15");
                    }
    
}
}



