package controller;


import DAO.ConexaoAdm;
import DAO.SaldoDAO;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import model.Saldo;
import view.ConsultarSaldo;


public class ControllerSaldo {
    
    private ConsultarSaldo view;
   // private ConSaldoFrame view2;
    private static String CpfLogin;
    
    public ControllerSaldo(ConsultarSaldo view){
        this.view = view;
       // this.view2 = new ConSaldoFrame();
        
    }

    public static String getCpfLogin() {
        return CpfLogin;
    }

    public static void setCpfLogin(String CpfLogin) {
        ControllerSaldo.CpfLogin = CpfLogin;
    }
     
        
    
    
    public void Saldo(){
        Saldo sf = new Saldo(view.getTxtcpfsaldo().getText(),null);
        
        ConexaoAdm conexao = new ConexaoAdm();
        try{
            Connection conn = conexao.getConnection();
            SaldoDAO dao = new SaldoDAO(conn);
            ResultSet res = dao.consultar(sf);

        if (res.next()){
                JOptionPane.showMessageDialog(view, "Saldo Acessado", "Aviso",
                        JOptionPane.INFORMATION_MESSAGE);
                
                String senha = res.getString("senha");
                String nome = res.getString("nome");
                System.out.println("jjjjjjjjjjjj");
                Saldo sf1 = new Saldo(view.getTxtcpfsaldo().getText(), senha);
               System.out.println("nnnnnnnnnnnnnnnn");
                conn = conexao.getConnection();
                SaldoDAO dao2 = new SaldoDAO(conn);
                System.out.println("kkkkkkkkkk");
                res = dao2.consultarsaldo(sf1);
                System.out.println("llllll");
                if(res.next()){
                    System.out.println("ppppppppp");
                    double saldo = res.getDouble("saldo");
                    double saldobtc = res.getDouble("saldobtc");
                    double saldoeth = res.getDouble("saldoeth");
                    double saldoxrp = res.getDouble("saldoxrp");
                    view.getTxtsaldo().setText("Nome: " + nome + "\nCPF: " + view.getTxtcpfsaldo().getText() + "\nReal: " + saldo + " \nBtc: " + saldobtc + " \nEth: " + saldoeth + "\nXrp: " + saldoxrp);

                }
                
        }else{
            JOptionPane.showMessageDialog(view, "Saldo não acessado", "Erro",
                        JOptionPane.ERROR_MESSAGE);
        }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(view, "Erro de Conexão", "Erro",
                        JOptionPane.ERROR_MESSAGE);
       }
}
}

