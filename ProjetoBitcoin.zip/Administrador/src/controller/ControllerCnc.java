
package controller;

import DAO.CdcDAO;
import DAO.ConexaoAdm;
import view.CdNewCripto;
import model.Cdc;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class ControllerCnc {
private CdNewCripto view;

    public ControllerCnc(CdNewCripto view) {
        this.view = view;
    }
    
  public void Cadastro(){
        String nome = view.getTxtmoeda().getText();
        double cotacao = Double.parseDouble(view.getTxtcotacao().getText());
        
        Cdc cadastro = new Cdc(nome, cotacao);
        ConexaoAdm conn = new ConexaoAdm();
        
       try{
           Connection connection = conn.getConnection();
           CdcDAO dao = new CdcDAO(connection);
           dao.inserir(cadastro);
           JOptionPane.showMessageDialog(view, "moeda Cadastrada com Sucesso", "Cadastrado!", JOptionPane.INFORMATION_MESSAGE);
       }
       catch(SQLException e){
           JOptionPane.showMessageDialog(view, "Falha no Cadastro.", "Erro!", JOptionPane.ERROR_MESSAGE);
           e.printStackTrace();
       }
    }
}



