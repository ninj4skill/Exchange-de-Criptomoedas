
package controller;
import DAO.LoginAdmDAO;
import DAO.ConexaoAdm;
import view.Cadastro;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.LoginAdm;

public class ControllerCadastro {
    
    private Cadastro view;
    
    public ControllerCadastro (Cadastro view){
        this.view = view;
    }
   
    public void SalvarUsuario(){
        String nome = view.getTxtcadastronome().getText();
        String cpf = view.getTxtcadastrocpf().getText();
        String senha = view.getCadastrosenha().getText();
        LoginAdm cadastro = new LoginAdm(nome, cpf, senha);
        ConexaoAdm conn = new ConexaoAdm();
        
       try{
           Connection connection = conn.getConnection();
           LoginAdmDAO dao = new LoginAdmDAO(connection);
           dao.inserir(cadastro);
           JOptionPane.showMessageDialog(view, "Usuário Cadastrado com Sucesso", "Cadastrado!", JOptionPane.INFORMATION_MESSAGE);
       }
       catch(SQLException e){
           JOptionPane.showMessageDialog(view, "Falha no Cadastro.", "Erro!", JOptionPane.ERROR_MESSAGE);
           e.printStackTrace();
       }
    }
}



